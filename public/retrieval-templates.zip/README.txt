TNT Teaching Tools retrieval templates

Replace bracketed text with your own taught content before using a template.
Word: eight worksheets, individually and as one pack.
PowerPoint: fourteen editable activity slides, individually and as one pack.
PowerPoint teacher guidance and credits are in the speaker notes.
Full illustrated guides: https://tnt-teaching-tools.github.io/cold-call-classroom/retrieval.html
